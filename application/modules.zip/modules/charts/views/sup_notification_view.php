<div class="alert" style="background-color: #DADFE1;color:black;">
	<?php //echo $suppressions['county'];?> Non-suppression <?php echo $suppressions['year'].$suppressions['month'];?>: 
	<?php echo $suppressions['sustxfail'];?>&nbsp;(<strong><?php echo $suppressions['rate'];?>%</strong>)
</div>

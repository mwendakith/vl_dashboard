<div class="alert" style="background-color: #CF000F">
	<?php echo $suppressions['county'];?> Non-suppression rate <?php echo $suppressions['year'].$suppressions['month'];?>: 
	<strong><?php echo $suppressions['rate'];?>%</strong>
</div>

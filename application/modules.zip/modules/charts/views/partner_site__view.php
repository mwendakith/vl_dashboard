<thead>
	<tr>
		<th>#</th>
		<th>MFL Code</th>
		<th>Name</th>
		<th>County</th>
		<th>Tests</th>
		<th>Suspected Failures</th>
		<th>Repeat VL</th>
		<th>Confirmed Tx</th>
		<th>Rejected</th>
		<th>Adult Tests</th>
		<th>Paeds Tests</th>
		<th>Male</th>
		<th>Female</th>
	</tr>
</thead>
<tbody>
	<?php echo $outcomes;?>
</tbody>
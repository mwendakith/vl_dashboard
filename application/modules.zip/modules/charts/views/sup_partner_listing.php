<div class="list-group">
	<?php echo $partners;?>
</div>
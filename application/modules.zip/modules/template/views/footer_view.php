		</div>
		<!-- End of Dashboard area -->
	</body>
</html>
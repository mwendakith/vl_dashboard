<script type="text/javascript">
	$().ready(function(){
		$("#siteOutcomes").load("<?php echo base_url('charts/sites/site_outcomes');?>");
	});
</script>
<script type="text/javascript">
	$().ready(function(){
		$("#nattat").load("<?php echo base_url('charts/summaries/turnaroundtime'); ?>");
		$("#samples").load("<?php echo base_url('charts/summaries/sample_types'); ?>");
		$("#county").load("<?php echo base_url('charts/summaries/county_outcomes'); ?>"); 
		$("#vlOutcomes").load("<?php echo base_url('charts/summaries/vl_outcomes'); ?>");
		$("#justification").load("<?php echo base_url('charts/summaries/justification'); ?>"); 
		$("#ageGroups").load("<?php echo base_url('charts/summaries/age'); ?>"); 
		$("#gender").load("<?php echo base_url('charts/summaries/gender'); ?>");

		$(".display_date").load("<?php echo base_url('charts/summaries/display_date'); ?>");
		$(".display_range").load("<?php echo base_url('charts/summaries/display_range'); ?>");

		$('#filter_form').submit(function( event ) {
         
	        // Stop form from submitting normally
	        event.preventDefault();
	        
	        // Get some values from elements on the page:
	        var $form = $( this ),
	        em = $form.find( "select[name='county']" ).val(),
	        url = $form.attr( "action" );
	        
	        // Send the data using post
	        var posting = $.post( url, { county: em } );
	     
	        // Put the results in a div
	        posting.done(function( data ) {
	        	$.get("<?php echo base_url();?>template/breadcrum", function(data){
	        		$("#breadcrum").html(data);
	        	});
	        	$.get("<?php echo base_url();?>template/dates", function(data){
	        		obj = $.parseJSON(data);
			
					if(obj['month'] == "null" || obj['month'] == null){
						obj['month'] = "";
					}
					$(".display_date").html("( "+obj['year']+" "+obj['month']+" )");
					$(".display_range").html("( "+obj['prev_year']+" - "+obj['year']+" )");
	        	});
	        	
	        	$("#nattat").html("<div>Loading...</div>");
	        	$("#samples").html("<div>Loading...</div>");
		        $("#vlOutcomes").html("<div>Loading...</div>");
				$("#justification").html("<div>Loading...</div>");
				$("#ageGroups").html("<div>Loading...</div>");
				$("#gender").html("<div>Loading...</div>");
				// $("#county").load("<?php //echo base_url('charts/summaries/county_outcomes'); ?>/"+null+"/"+null+"/"+data);
				$("#nattat").load("<?php echo base_url('charts/summaries/turnaroundtime'); ?>");
				$("#samples").load("<?php echo base_url('charts/summaries/sample_types'); ?>/"+null+"/"+data);
				$("#vlOutcomes").load("<?php echo base_url('charts/summaries/vl_outcomes'); ?>/"+null+"/"+null+"/"+data); 
				$("#justification").load("<?php echo base_url('charts/summaries/justification'); ?>/"+null+"/"+null+"/"+data); 
				$("#ageGroups").load("<?php echo base_url('charts/summaries/age'); ?>/"+null+"/"+null+"/"+data); 
				$("#gender").load("<?php echo base_url('charts/summaries/gender'); ?>/"+null+"/"+null+"/"+data); 
	        });
    	});
	});

	function date_filter(criteria, id)
 	{
 		if (criteria === "monthly") {
 			year = null;
 			month = id;
 		}else {
 			year = id;
 			month = null;
 		}

 		var posting = $.post( '<?php echo base_url();?>summary/set_filter_date', { 'year': year, 'month': month } );

 		// Put the results in a div
		posting.done(function( data ) {
			obj = $.parseJSON(data);
			
			if(obj['month'] == "null" || obj['month'] == null){
				obj['month'] = "";
			}
			$(".display_date").html("( "+obj['year']+" "+obj['month']+" )");
			$(".display_range").html("( "+obj['prev_year']+" - "+obj['year']+" )");
			
		});
 		
 		$("#samples").html("<div>Loading...</div>");
		$("#nattat").html("<div>Loading...</div>");
 		$("#county").html("<div>Loading...</div>"); 
		$("#vlOutcomes").html("<div>Loading...</div>");
		$("#justification").html("<div>Loading...</div>");
		$("#ageGroups").html("<div>Loading...</div>");
		$("#gender").html("<div>Loading...</div>");

		$("#nattat").load("<?php echo base_url('charts/summaries/turnaroundtime'); ?>");
		$("#samples").load("<?php echo base_url('charts/summaries/sample_types'); ?>/"+year);
 		$("#county").load("<?php echo base_url('charts/summaries/county_outcomes'); ?>/"+year+"/"+month); 
		$("#vlOutcomes").load("<?php echo base_url('charts/summaries/vl_outcomes'); ?>/"+year+"/"+month);
		$("#justification").load("<?php echo base_url('charts/summaries/justification'); ?>/"+year+"/"+month); 
		$("#ageGroups").load("<?php echo base_url('charts/summaries/age'); ?>/"+year+"/"+month); 
		$("#gender").load("<?php echo base_url('charts/summaries/gender'); ?>/"+year+"/"+month);
	}

	function ageModal()
	{
		$('#agemodal').modal('show');
		$('#CatAge').load('<?php echo base_url();?>charts/summaries/agebreakdown');
	}
	
</script>
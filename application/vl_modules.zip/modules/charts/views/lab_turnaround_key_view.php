<div class="col-md-6" style="border: 1px solid black">
        <div class="title-name">Key</div>
            <div class="row">
                <div class="col-md-6">
                    <div class="key cr"><center>Collection Receipt (C-R)</center></div>
                    <div class="key rp"><center>Receipt to Processing (R-P)</center></div>
                </div>
                <div class="col-md-6">
                    <div class="key pd"><center>Processing Dispatch (P-D)</center></div>
                    <div class="key"><center><div class="cd"></div>Collection Dispatch (C-D)</center></div>
                </div>
            </div>
    </div>
</div>